import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';

import { MenulistitemComponent } from './menulistitem.component';

describe('MenulistitemComponent', () => {
  let component: MenulistitemComponent;
  let fixture: ComponentFixture<MenulistitemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MenulistitemComponent],
      imports: [
        MatToolbarModule,
        MatButtonModule,
        MatSidenavModule,
        MatIconModule,
        MatListModule,
        RouterTestingModule
      ],
      providers: [],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenulistitemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
