import { Component } from '@angular/core';
import { NavItemModel } from './nav-item-model';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ClientApp';
  navItemsModel: NavItemModel[] = [
    {
      displayName: 'Home',
      iconName: 'close',
      route: 'home'
    },
    {
      displayName: 'Alert',
      iconName: 'close',
      children: [
        {
          displayName: 'Item Alert',
          iconName: 'group',
          route: 'item-alert'
        },
        {
          displayName: 'Second Item Alert',
          iconName: 'group',
          route: 'second-item-alert'
        },
        {
          displayName: 'Feedback',
          iconName: 'feedback',
          route: 'feedback'
        }
      ]
    },
    {
      displayName: 'Case',
      iconName: 'close',
      children: [
        {
          displayName: 'Create Case',
          iconName: 'group',
          route: 'item-alert'
        },
        {
          displayName: 'View Case',
          iconName: 'group',
          route: 'second-item-alert'
        },
        {
          displayName: 'Feedback',
          iconName: 'feedback',
          route: 'feedback'
        }
      ]
    }
  ];

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
  );

  constructor(private breakpointObserver: BreakpointObserver) { }
}
