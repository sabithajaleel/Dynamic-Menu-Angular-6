export interface NavItemModel {
  displayName: string;
  disabled?: boolean;
  iconName: string;
  route?: string;
  children?: NavItemModel[];
}
